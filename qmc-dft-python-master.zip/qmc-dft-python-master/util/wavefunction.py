#!/usr/bin/env python
import sys

sys.dont_write_bytecode = True

class Wavefunction():
    def __init__(self):
        self.
    def local_energy(self, 
